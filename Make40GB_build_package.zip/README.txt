README - Make40GBRandom build package

What you get:
- Make40GBRandom.cs : C# source that writes a 40 GB file with cryptographically-random bytes.
- build_and_publish.bat : Batch script that creates a new dotnet console project and publishes a
  single-file self-contained Windows x64 executable. Requires .NET SDK installed locally.

How to build (on a Windows machine with .NET SDK installed):
1. Extract this zip.
2. Double-click build_and_publish.bat or run it from an elevated Command Prompt (optional).
3. Wait — publishing a self-contained exe will download runtime packs (if not present) and compile.
4. The resulting .exe will be placed under the project's bin\Release\...\publish folder.

IMPORTANT WARNINGS:
- The produced executable will create a 40 GB file. Ensure you have at least 40 GB free on the target drive.
- Creating large random files is very I/O intensive and may take many minutes/hours depending on disk speed.
- Use on a drive where data loss/SSD wear is acceptable.
- Stop the program with CTRL+C if needed.

If you want me to create and host the actual .exe here (so you can download it directly), I cannot do that from this environment.
I can, however, produce this zip package (source + build script) for you to download and build locally. 
