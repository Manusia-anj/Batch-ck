using System;
using System.IO;
using System.Security.Cryptography;

class Make40GbRandom
{
    // 40 GB = 40 * 1024^3 bytes
    const long TARGET_BYTES = 40L * 1024L * 1024L * 1024L;
    // chunk size per write (default: 8 MB). Bisa diubah.
    const int CHUNK_SIZE = 8 * 1024 * 1024;

    static volatile bool _canceled = false;

    static void Main(string[] args)
    {
        Console.WriteLine("Make40GbRandom - menulis file 40 GB berisi random bytes");
        Console.WriteLine("CTRL+C untuk membatalkan.");

        string outPath;
        if (args.Length >= 1)
        {
            outPath = args[0];
        }
        else
        {
            string ts = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
            outPath = Path.Combine(Directory.GetCurrentDirectory(), $"file_40GB_random_{ts}.bin");
        }

        Console.CancelKeyPress += (s, e) =>
        {
            Console.WriteLine();
            Console.WriteLine("SIGINT diterima — mencoba berhenti dengan rapi...");
            _canceled = true;
            e.Cancel = true; // beri kesempatan untuk cleanup
        };

        try
        {
            using (var fs = new FileStream(outPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, CHUNK_SIZE, FileOptions.WriteThrough))
            using (var rng = RandomNumberGenerator.Create())
            {
                long written = 0;
                byte[] buffer = new byte[CHUNK_SIZE];
                DateTime start = DateTime.UtcNow;

                while (written < TARGET_BYTES && !_canceled)
                {
                    int toWrite = (int)Math.Min(CHUNK_SIZE, TARGET_BYTES - written);
                    if (toWrite != buffer.Length)
                    {
                        buffer = new byte[toWrite];
                    }

                    rng.GetBytes(buffer);
                    fs.Write(buffer, 0, toWrite);
                    written += toWrite;

                    double percent = (written / (double)TARGET_BYTES) * 100.0;
                    double writtenGb = written / 1024.0 / 1024.0 / 1024.0;
                    TimeSpan elapsed = DateTime.UtcNow - start;
                    double speedMBs = (written / 1024.0 / 1024.0) / Math.Max(1.0, elapsed.TotalSeconds);

                    Console.Write($"\r{percent:0.00}% — {writtenGb:0.00} GB / 40.00 GB — {speedMBs:0.00} MB/s   ");
                }

                Console.WriteLine();
                if (_canceled)
                {
                    Console.WriteLine("Dibatalkan. File sebagian tetap ada: " + outPath);
                }
                else
                {
                    Console.WriteLine("Selesai! File 40 GB dibuat: " + outPath);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine();
            Console.WriteLine("Error: " + ex.Message);
        }
    }
}
